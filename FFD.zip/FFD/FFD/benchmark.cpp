#include "stdafx.h"
#include "virtual.h"
#include "benchmark.h"
#include <io.h>
#include <fstream>
#include <string>

using namespace std;

Benchmark::Benchmark() {
	
}

vector<string> Benchmark::getfilename(const char* filepath)
{
	vector<string> filename;
	long handle;                                                //���ڲ��ҵľ��
	struct _finddata_t fileinfo;                          //�ļ���Ϣ�Ľṹ��
	handle = _findfirst(filepath, &fileinfo);         //��һ�β���
	if (-1 == handle) {
		exit(1);
	}
	filename.push_back(fileinfo.name);                         //��ӡ���ҵ����ļ����ļ���
	while (!_findnext(handle, &fileinfo))               //ѭ�������������ϵ��ļ���֪���Ҳ���������Ϊֹ
	{
		filename.push_back(fileinfo.name);
	}
	_findclose(handle);                                      //�����˹رվ��
	filepath = NULL;
	return filename;
}


vector<string> split(string s)
{
	vector<string> ret;
	vector<string> data;
	string tmp;
	s = s + " ";
	size_t start = 0, pos = s.find(" ", 0);
	while (pos != s.npos)
	{
		tmp = s.substr(start, pos);
		ret.push_back(tmp);
		s = s.substr(pos + 1, s.size());
		pos = s.find(" ", 0);
	}
	for (int i = 0; i < ret.size(); i++) {
		data.push_back(ret[i]);
	}
	return data;
}

map<VIRTUAL, int> Benchmark::load(string filename)
{

	map<VIRTUAL, int> map_v;
	string filepath = "C:\\Users\\����\\Desktop\\�Ƽ���\\����\\vmp_cpu_mem_discV3\\VMP\\data\\" + filename;
	ifstream infile(filepath);
	string tmp_data;
	vector<string> data;
	map<VIRTUAL, int>::iterator it;
	if (!infile) {
		exit(0);
	}
	getline(infile, tmp_data);
	VIRTUAL v;
	while (getline(infile, tmp_data)) {
		data = split(tmp_data);
		v.set(atoi(data[0].c_str()), atoi(data[1].c_str()), atoi(data[2].c_str()), atoi(data[3].c_str()), atof(data[4].c_str()));
		it = map_v.find(v);
		if (it == map_v.end()) {
			map_v.insert(make_pair(v, 1));
		}
		else {
			it->second++;
		}
	}
	return map_v;
}
