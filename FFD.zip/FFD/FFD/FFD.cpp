#include "stdafx.h"
#include <random>
#include <iostream>
#include "virtual.h"
#include <vector>
#include "server.h"
#include <time.h>
#include <fstream>
#include <cmath>
#include "benchmark.h"
#include <string>

using namespace std;

//CPU,RAM required for VM
vector<int> vc;
vector<int> vm;

bool comp(SERVER b1, SERVER b2) {
	return b1.utilization > b2.utilization ? true : false;
}

vector<int> split(string s)
{
	vector<string> ret;
	vector<int> data;
	string tmp;
	int position = 0;
	unsigned int start = 0;
	while (start < s.size() - 2) {
		position = s.find(" ", start);
		if (position == -1) {
			break;
		}
		tmp = s.substr(start, position - start);
		start = position + 1;
		data.push_back(atoi(tmp.c_str()));
	}
	tmp = s.substr(start, s.size() - start - 1);
	data.push_back(atoi(tmp.c_str()));
	return data;
}


int main() {
	string filepath = "C://Users//����//Desktop//�Ƽ���//����//FFD_ԭʼ����//FFD//data//data5.txt";
	string tmp_data;
	int index = 1;
	vector<int> data;
	ifstream infile_data(filepath);
	if (!infile_data) {
		exit(0);
	}
	getline(infile_data, tmp_data);
	getline(infile_data, tmp_data);
	getline(infile_data, tmp_data);
	getline(infile_data, tmp_data);
	while (getline(infile_data, tmp_data)) {
		data = split(tmp_data);
		vc.push_back(data[0]);
		vm.push_back(data[1]);
		index++;
	}

	SERVER s(500, 500);
	vector<SERVER> box;
	vector<SERVER> final_box;
	bool flag;
	for (int i = 0; i < vc.size(); i++) {
		flag = true;
		for (int j = 0; j < box.size(); j++) {
			if ((box[j].current_CPU - vc[i] >= 0) && (box[j].current_MEM - vm[i] >= 0)) {
				box[j].current_CPU = box[j].current_CPU - vc[i];
				box[j].current_MEM = box[j].current_MEM - vm[i];
				flag = false;
				box[j].utilization = (double)(box[j].MAX_CPU - box[j].current_CPU) / box[j].MAX_CPU
					+ (double)(box[j].MAX_MEM - box[j].current_MEM) / box[j].MAX_MEM;
				if (box[j].current_CPU == 0 || box[j].current_MEM == 0) {
					final_box.push_back(box[j]);
					box.erase(box.begin() + j);
				}
				break;
			}
		}
		if (flag) {
			s.reset(500, 500);
			if ((s.current_CPU - vc[i] >= 0) && (s.current_MEM - vm[i] >= 0)) {
				s.current_CPU = s.current_CPU - vc[i];
				s.current_MEM = s.current_MEM - vm[i];
			}
			box.push_back(s);
		}
		sort(box.begin(), box.end(), comp);
	}
	final_box.insert(final_box.end(), box.begin(), box.end());
	cout << "FFD: " << final_box.size() << endl;
	system("PAUSE ");
	return 0;
}