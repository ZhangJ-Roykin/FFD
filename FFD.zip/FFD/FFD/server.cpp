#include "stdafx.h"
#include "server.h"

#define GENERAL_SERVER_CPU 56
#define GENERAL_SERVER_MEM 128
#define GENERAL_SERVER_DISC 1200
#define GENERAL_SERVER_PRICE 698
#define LARGE_MEM_SERVER_CPU 84
#define LARGE_MEM_SERVER_MEM 256
#define LARGE_MEM_SERVER_DISC 2400
#define LARGE_MEM_SERVER_PRICE 870
#define HIGHT_PER_SERVER_CPU 112
#define HIGHT_PER_SERVER_MEM 192
#define HIGHT_PER_SERVER_DISC 3600
#define HIGHT_PER_SERVER_PRICE 1090


SERVER::SERVER(int CPU, int MEM){
	current_MEM = MEM;
	current_CPU = CPU;
	MAX_MEM = MEM;
	MAX_CPU = CPU;
}


void SERVER::reset(int t_MEM, int t_CPU) {
	MAX_MEM = t_MEM;
	MAX_CPU = t_CPU;
	current_CPU = MAX_CPU;
	current_MEM = MAX_MEM;
	vir.clear();
}
