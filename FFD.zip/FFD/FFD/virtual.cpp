#include "stdafx.h"
#include "virtual.h"

VIRTUAL::VIRTUAL(int s, int C, int M, int D, double P) {
	MEM = M;
	CPU = C;
	DISC = D;
	Price = P;
	ID = s;
}

VIRTUAL::VIRTUAL()
{
}

void VIRTUAL::set(int s, int C, int M,int D, double P)
{
	MEM = M;
	CPU = C;
	DISC = D;
	Price = P;
	ID = s;
}




