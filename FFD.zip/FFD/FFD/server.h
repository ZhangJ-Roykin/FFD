#ifndef _SERVER_H_
#define _SERVER_H_

#include "virtual.h"
#include <vector>

using namespace std;

class SERVER {

public:
	int current_MEM;
	int current_CPU;
	int MAX_MEM;
	int MAX_CPU;
	vector<VIRTUAL> vir;
	double utilization;

public:
	SERVER(int CPU, int MEM);
	void reset(int t_MEM, int t_CPU);
	void set();
	static vector<SERVER> initial();
	bool operator< (const SERVER &v)const {
		if (v.utilization < utilization) {
			return true;
		}
		return false;
	}
};

#endif // !_SERVER_H_
