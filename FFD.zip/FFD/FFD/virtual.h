#ifndef _VIRTUAL_H_
#define _VIRTUAL_H_

#include<vector>

using namespace std;

class VIRTUAL {

public:
	int MEM;
	int CPU;
	int DISC;
	double Price;
	int ID;
	
public:
	VIRTUAL(int s, int C, int M, int D, double P);
	VIRTUAL();
	void set(int s, int C, int M, int D, double P);
	bool operator<(const VIRTUAL &v)const {
		if (ID < v.ID) {
			return true;
		}
		return false;
	}
	bool operator==(const VIRTUAL &v)const {
		if (ID == v.ID) {
			return true;
		}
		return false;
	}
};


#endif // ! _VIRTUAL_H_

