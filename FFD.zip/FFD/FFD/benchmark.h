#ifndef _BENCHMARK_H_
#define _BENCHMARK_H_

#include <map>

class Benchmark {

public:
	Benchmark();

public:
	//void create();
	vector<string> getfilename(const char* filepath);
	map<VIRTUAL, int> load(string filename);

};

#endif